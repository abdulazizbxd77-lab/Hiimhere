package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class AppInfo(val label: String, val pkg: String)
class Art(val bmp: ImageBitmap, val banner: Boolean)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val out = LinkedHashMap<String, AppInfo>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (r in pm.queryIntentActivities(i, 0)) {
            val p = r.activityInfo.packageName
            if (p != ctx.packageName && p !in out) out[p] = AppInfo(r.loadLabel(pm).toString(), p)
        }
    }
    return out.values.sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(i) }
}

fun openSystem(ctx: Context, action: String) {
    runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private val cache = ConcurrentHashMap<String, Art>()

suspend fun loadArt(ctx: Context, pkg: String, wantBanner: Boolean): Art? = withContext(Dispatchers.Default) {
    val k = "$pkg$wantBanner"
    cache[k] ?: runCatching {
        val pm = ctx.packageManager
        val b = if (wantBanner) pm.getApplicationBanner(pkg) else null
        if (b != null) Art(b.toBitmap(320, 180).asImageBitmap(), true)
        else Art(pm.getApplicationIcon(pkg).toBitmap(192, 192).asImageBitmap(), false)
    }.getOrNull()?.also { cache[k] = it }
}

fun decodeUri(ctx: Context, s: String): ImageBitmap? = runCatching {
    val u = Uri.parse(s)
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var ss = 1
    while (o.outWidth / ss > 2400) ss *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
}.getOrNull()
