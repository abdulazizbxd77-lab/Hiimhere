package com.example.tvlauncher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("tvhome", Context.MODE_PRIVATE)
    var layout by mutableStateOf(sp.getInt("layout", 0))          // 0 Dock, 1 Cards, 2 Grid
    var wall by mutableStateOf(sp.getInt("wall", 0))
    var wallUri by mutableStateOf(sp.getString("wallUri", "") ?: "")
    var accent by mutableStateOf(sp.getInt("accent", 0))
    var clock24 by mutableStateOf(sp.getBoolean("clock24", false))
    var clockSize by mutableStateOf(sp.getInt("clockSize", 140))
    var clockCenter by mutableStateOf(sp.getBoolean("clockCenter", false))
    var showDate by mutableStateOf(sp.getBoolean("showDate", true))
    var scenery by mutableStateOf(sp.getBoolean("scenery", true))
    var greeting by mutableStateOf(sp.getString("greeting", "") ?: "")
    var shape by mutableStateOf(sp.getInt("shape", 0))            // 0 rounded, 1 circle, 2 square
    var tile by mutableStateOf(sp.getInt("tile", 110))
    var labels by mutableStateOf(sp.getBoolean("labels", true))
    var dim by mutableStateOf(sp.getInt("dim", 15))
    var hidden by mutableStateOf((sp.getString("hidden", "") ?: "").split("|").filter { it.isNotEmpty() }.toSet())

    fun edit(b: Prefs.() -> Unit) { b(); save() }

    private fun save() {
        sp.edit().putInt("layout", layout).putInt("wall", wall).putString("wallUri", wallUri)
            .putInt("accent", accent).putBoolean("clock24", clock24).putInt("clockSize", clockSize)
            .putBoolean("clockCenter", clockCenter).putBoolean("showDate", showDate)
            .putBoolean("scenery", scenery).putString("greeting", greeting).putInt("shape", shape)
            .putInt("tile", tile).putBoolean("labels", labels).putInt("dim", dim)
            .putString("hidden", hidden.joinToString("|")).apply()
    }
}
