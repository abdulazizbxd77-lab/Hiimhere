package com.example.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            prefs.edit { wallUri = uri.toString(); wall = CUSTOM }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContent { Root(prefs) { runCatching { pick.launch(arrayOf("image/*")) } } }
    }
}

@Composable
fun Root(p: Prefs, pickImage: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(loadApps(ctx)) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { apps = loadApps(c) }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        ctx.registerReceiver(r, f)
        onDispose { ctx.unregisterReceiver(r) }
    }
    var settings by remember { mutableStateOf(false) }
    BackHandler { settings = false }
    val accent = Accents[p.accent.coerceIn(0, Accents.lastIndex)]
    Box(Modifier.fillMaxSize().onPreviewKeyEvent { e ->
        val toggle = e.key == Key.Menu || e.key == Key.F2 || (e.key == Key.S && !settings)
        if (toggle) { if (e.type == KeyEventType.KeyUp) settings = !settings; true } else false
    }) {
        Wallpaper(p)
        if (settings) SettingsScreen(p, apps, accent, pickImage) { settings = false }
        else Home(p, apps.filter { it.pkg !in p.hidden }, accent) { settings = true }
    }
}
