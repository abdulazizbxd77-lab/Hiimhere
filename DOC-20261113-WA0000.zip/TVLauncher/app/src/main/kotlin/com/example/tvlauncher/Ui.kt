package com.example.tvlauncher

import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

class Wall(val name: String, val colors: List<Color>)
private fun c(vararg l: Long) = l.map { Color(it) }
val Walls = listOf(
    Wall("Dusk", c(0xFF1B1035, 0xFF6B3A7D, 0xFFE8697D, 0xFFFFB38A)),
    Wall("Aurora", c(0xFF04122B, 0xFF0B5D63, 0xFF2FBF8F)),
    Wall("Midnight", c(0xFF05060F, 0xFF101830, 0xFF1C2B55)),
    Wall("Ocean", c(0xFF031A33, 0xFF0A5C8C, 0xFF5CC2E8)),
    Wall("Ember", c(0xFF120505, 0xFF5A1A0E, 0xFFFF7A2E)),
    Wall("Haunt", c(0xFF07060F, 0xFF241238, 0xFF6A2C0E)),
    Wall("Mono", c(0xFF0A0A0A, 0xFF1E1E1E, 0xFF3A3A3A)),
)
val CUSTOM = Walls.size
val Accents = c(0xFF00B8F0, 0xFFFF5C8A, 0xFFFF8A3D, 0xFF3DDC84, 0xFF9B6BFF, 0xFFFF4D4D)

fun greeting(p: Prefs): String = p.greeting.ifBlank {
    when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 0..4 -> "Good night"; in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening"
    }
}

// ---------- building blocks ----------
@Composable
fun Focusy(
    modifier: Modifier = Modifier, shape: Shape, accent: Color,
    bg: Color = Color.White.copy(alpha = .14f), onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val hov by src.collectIsHoveredAsState()
    val foc by src.collectIsFocusedAsState()
    val on = hov || foc
    val s by animateFloatAsState(if (on) 1.08f else 1f, tween(120), label = "s")
    Box(
        modifier.zIndex(if (on) 1f else 0f).graphicsLayer { scaleX = s; scaleY = s }
            .clip(shape).background(bg)
            .then(if (on) Modifier.border(3.dp, if (foc) Color.White else accent, shape) else Modifier)
            .hoverable(src).clickable(interactionSource = src, indication = null, onClick = onClick),
        content = content
    )
}

@Composable
fun Pill(label: String, accent: Color, onClick: () -> Unit) =
    Focusy(shape = RoundedCornerShape(50), accent = accent, onClick = onClick) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
    }

@Composable
fun Pills(accent: Color, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Pill("Wi-Fi", accent) { openSystem(ctx, Settings.ACTION_WIFI_SETTINGS) }
        Pill("System", accent) { openSystem(ctx, Settings.ACTION_SETTINGS) }
        Pill("Customize", accent, openSettings)
    }
}

@Composable
fun Frost(content: @Composable BoxScope.() -> Unit) =
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(Color.White.copy(alpha = .10f)).padding(14.dp), content = content)

@Composable
fun AppTile(app: AppInfo, p: Prefs, accent: Color, wide: Boolean) {
    val ctx = LocalContext.current
    val art by produceState<Art?>(null, app.pkg, wide) { value = loadArt(ctx, app.pkg, wide) }
    val w = if (wide) (p.tile * 1.8f).dp else p.tile.dp
    val shape = when {
        p.shape == 1 && !wide -> CircleShape
        p.shape == 2 -> RoundedCornerShape(4.dp)
        else -> RoundedCornerShape(22.dp)
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Focusy(Modifier.size(w, p.tile.dp), shape, accent, onClick = { launchApp(ctx, app.pkg) }) {
            art?.let { a ->
                if (a.banner) Image(a.bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Image(a.bmp, null, Modifier.align(Alignment.Center).fillMaxSize(0.62f))
            }
        }
        if (p.labels) Text(
            app.label, color = Color.White.copy(alpha = .9f), fontSize = 14.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.width(w).padding(top = 8.dp)
        )
    }
}

// ---------- wallpaper ----------
@Composable
fun Wallpaper(p: Prefs) {
    val ctx = LocalContext.current
    val custom = p.wall == CUSTOM && p.wallUri.isNotEmpty()
    val bmp by produceState<ImageBitmap?>(null, p.wallUri, custom) {
        value = if (custom) withContext(Dispatchers.IO) { decodeUri(ctx, p.wallUri) } else null
    }
    val cols = Walls[p.wall.coerceIn(0, Walls.lastIndex)].colors
    Box(Modifier.fillMaxSize()) {
        if (custom && bmp != null) {
            Image(bmp!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.verticalGradient(cols))
                if (p.scenery) {
                    val w = size.width; val h = size.height
                    fun ridge(base: Float, amp: Float, seed: Int, a: Float) {
                        val path = Path(); path.moveTo(0f, h)
                        var x = 0f
                        while (x <= w + 40f) {
                            val t = x / w
                            val y = h * base - amp * (abs(sin(t * 5f + seed)) * .7f + abs(sin(t * 13f + seed * 2)) * .3f)
                            path.lineTo(x, y); x += w / 60f
                        }
                        path.lineTo(w, h); path.close()
                        drawPath(path, Color.Black.copy(alpha = a))
                    }
                    ridge(.70f, h * .24f, 1, .30f); ridge(.80f, h * .20f, 3, .50f); ridge(.92f, h * .14f, 5, .75f)
                }
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = p.dim / 100f)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .55f)))))
    }
}

// ---------- clock ----------
@Composable
fun ClockBlock(p: Prefs, accent: Color, scale: Float) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000 - System.currentTimeMillis() % 1000) } }
    val loc = Locale.getDefault()
    val time = SimpleDateFormat(if (p.clock24) "HH:mm" else "h:mm", loc).format(now)
    val line = listOfNotNull(
        if (scale == 1f) greeting(p) else null,
        if (p.showDate) SimpleDateFormat("EEEE d MMMM", loc).format(now) else null
    ).joinToString("  ·  ").uppercase()
    val center = p.clockCenter && scale == 1f
    Column(
        if (center) Modifier.fillMaxWidth() else Modifier,
        horizontalAlignment = if (center) Alignment.CenterHorizontally else Alignment.Start
    ) {
        if (line.isNotEmpty()) Text(line, color = Color.White.copy(alpha = .8f), fontSize = 16.sp, letterSpacing = 2.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                time, style = TextStyle(
                    brush = Brush.verticalGradient(listOf(Color.White, accent)),
                    fontSize = (p.clockSize * scale).sp, fontWeight = FontWeight.Light
                )
            )
            if (!p.clock24) Text(
                SimpleDateFormat("a", loc).format(now), color = Color.White.copy(alpha = .8f),
                fontSize = (p.clockSize * scale * .2f).sp, modifier = Modifier.padding(start = 10.dp, bottom = (p.clockSize * scale * .2f).dp)
            )
        }
    }
}

// ---------- layouts ----------
@Composable
fun Home(p: Prefs, apps: List<AppInfo>, accent: Color, openSettings: () -> Unit) {
    when (p.layout) {
        0 -> Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 32.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Pills(accent, openSettings) }
            ClockBlock(p, accent, 1f)
            Spacer(Modifier.weight(1f))
            Frost {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(12.dp)) {
                    items(apps, key = { it.pkg }) { AppTile(it, p, accent, false) }
                }
            }
        }
        1 -> Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 32.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(greeting(p), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Pills(accent, openSettings)
            }
            ClockBlock(p, accent, .45f)
            Spacer(Modifier.weight(1f))
            Frost {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(12.dp)) {
                    items(apps, key = { it.pkg }) { AppTile(it, p, accent, true) }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 32.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                ClockBlock(p, accent, .45f)
                Pills(accent, openSettings)
            }
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                GridCells.Adaptive((p.tile + 30).dp), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
            ) { items(apps, key = { it.pkg }) { AppTile(it, p, accent, false) } }
        }
    }
}

// ---------- settings ----------
@Composable
fun Chip(t: String, sel: Boolean, accent: Color, onClick: () -> Unit) =
    Focusy(shape = RoundedCornerShape(14.dp), accent = accent, bg = if (sel) accent.copy(alpha = .85f) else Color.White.copy(alpha = .12f), onClick = onClick) {
        Text(t, color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(18.dp, 10.dp))
    }

@Composable
fun Chips(opts: List<String>, sel: Int, accent: Color, onSel: (Int) -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        opts.forEachIndexed { i, o -> Chip(o, i == sel, accent) { onSel(i) } }
    }

@Composable
fun Sec(t: String) = Text(t.uppercase(), color = Color.White.copy(alpha = .55f), fontSize = 14.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 14.dp))

@Composable
fun Toggle(label: String, v: Boolean, accent: Color, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Chip(if (v) "On" else "Off", v, accent) { onChange(!v) }
    }

@Composable
fun Step(label: String, v: Int, lo: Int, hi: Int, step: Int, unit: String, accent: Color, onChange: (Int) -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 18.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Chip("−", false, accent) { onChange((v - step).coerceAtLeast(lo)) }
            Text("$v$unit", color = Color.White, fontSize = 18.sp, modifier = Modifier.width(70.dp), textAlign = TextAlign.Center)
            Chip("+", false, accent) { onChange((v + step).coerceAtMost(hi)) }
        }
    }

@Composable
fun SettingsScreen(p: Prefs, apps: List<AppInfo>, accent: Color, pickImage: () -> Unit, close: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xF0090912))) {
        LazyColumn(
            Modifier.align(Alignment.Center).widthIn(max = 880.dp).fillMaxHeight(),
            contentPadding = PaddingValues(vertical = 32.dp, horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Customize", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Chip("Done", true, accent, close)
                }
            }
            item { Sec("Layout") }
            item { Chips(listOf("Dock", "Cards", "Grid"), p.layout, accent) { p.edit { layout = it } } }
            item { Sec("Wallpaper") }
            item { Chips(Walls.map { it.name } + "Photo", p.wall, accent) { if (it == CUSTOM && p.wallUri.isEmpty()) pickImage() else p.edit { wall = it } } }
            item { Row { Chip("Choose photo…", false, accent, pickImage) } }
            item { Toggle("Mountain scenery (gradients only)", p.scenery, accent) { p.edit { scenery = it } } }
            item { Step("Dimming", p.dim, 0, 80, 5, "%", accent) { p.edit { dim = it } } }
            item { Sec("Accent colour") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    Accents.forEachIndexed { i, col ->
                        Focusy(Modifier.size(44.dp), CircleShape, Color.White, bg = col, onClick = { p.edit { accent = i } }) {
                            if (p.accent == i) Text("✓", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
                        }
                    }
                }
            }
            item { Sec("Clock") }
            item { Toggle("24-hour time", p.clock24, accent) { p.edit { clock24 = it } } }
            item { Toggle("Show date", p.showDate, accent) { p.edit { showDate = it } } }
            item { Toggle("Centre clock (Dock layout)", p.clockCenter, accent) { p.edit { clockCenter = it } } }
            item { Step("Clock size", p.clockSize, 60, 240, 10, "", accent) { p.edit { clockSize = it } } }
            item { Sec("Greeting text") }
            item {
                BasicTextField(
                    value = p.greeting, onValueChange = { v -> p.edit { greeting = v } }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 18.sp), cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .12f)).padding(14.dp),
                    decorationBox = { inner ->
                        if (p.greeting.isEmpty()) Text("Auto (Good morning / afternoon / evening)", color = Color.White.copy(alpha = .5f), fontSize = 18.sp)
                        inner()
                    }
                )
            }
            item { Sec("Tiles") }
            item { Chips(listOf("Rounded", "Circle", "Square"), p.shape, accent) { p.edit { shape = it } } }
            item { Step("Tile size", p.tile, 70, 200, 10, "", accent) { p.edit { tile = it } } }
            item { Toggle("Show app names", p.labels, accent) { p.edit { labels = it } } }
            item { Sec("Apps on home screen") }
            items(apps, key = { it.pkg }) { app ->
                Toggle(app.label, app.pkg !in p.hidden, accent) { on -> p.edit { hidden = if (on) hidden - app.pkg else hidden + app.pkg } }
            }
        }
    }
}
